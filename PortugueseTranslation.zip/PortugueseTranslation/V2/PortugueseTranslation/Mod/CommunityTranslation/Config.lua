return {
	Title = "Taiwu Traducao Portugues Brasileiro",
	Author = "Yuri",
	Description = "Taiwu Traducao Portugues Brasileiro.",
	HasArchive = false,
	FrontendPlugins = {
		[1] = "TaiwuCommunityTranslation.Frontend.dll",
	},
	BackendPlugins = {
		[1] = "TaiwuCommunityTranslation.Backend.dll",
	},
	Source = 0,
	FileId = 200,
	Version = "0.0.71.78",
	GameVersion = "0.0.71.78",
	Visibility = 0,
	DefaultSettings = { },
	UpdateLogList = { },
	Cover = nil,
	WorkshopCover = nil,
}
