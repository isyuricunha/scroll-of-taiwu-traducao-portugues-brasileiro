return {
	Title = "[PT-BR] Tradução Português/Portugues Brasileiro",
	Author = "Yuri",
	Description = "Scroll of Taiwu - Português Brasileiro",
	HasArchive = false,
	FrontendPlugins = {
		[1] = "TaiwuCommunityTranslation.Frontend.dll",
	},
	BackendPlugins = {
		[1] = "TaiwuCommunityTranslation.Backend.dll",
	},
	Source = 1,
	FileId = 3305069082,
	Version = "0.0.71.78",
	GameVersion = "0.0.72.14",
	Visibility = 0,
	DefaultSettings = { },
	UpdateLogList = {
		[1] = {
			Timestamp = 1723110895,
		},
	},
	ChangeConfig = false,
	NeedRestartWhenSettingChanged = true,
	Cover = "vai-brasil.png",
	WorkshopCover = "vai-brasil.png",
	TagList = {
		[1] = "Configurations",
		[2] = "Extensions",
		[3] = "Display",
	},
}
